// js/storageService.js

let income = 0;
let expenses = [];

export function setIncome(value) {
  income = parseFloat(value) || 0;
}

export function addExpense(amount, desc) {
  expenses.push({
    amount: parseFloat(amount) || 0,
    description: desc
  });
}

export function getIncome() {
  return income;
}

export function getExpenses() {
  return expenses;
}
