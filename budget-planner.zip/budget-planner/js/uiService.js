// js/uiService.js

export function updateUI(income, totalExpenses, balance) {
  document.getElementById("showIncome").innerText = income;
  document.getElementById("showExpenses").innerText = totalExpenses;
  document.getElementById("showBalance").innerText = balance;
}

export function renderExpenses(expenses) {
  const list = document.getElementById("expenseList");
  list.innerHTML = "";

  expenses.forEach(exp => {
    const li = document.createElement("li");
    li.innerText = `₹${exp.amount} — ${exp.description}`;
    list.appendChild(li);
  });
}
