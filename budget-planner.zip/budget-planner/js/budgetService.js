// js/budgetService.js

export function calculateBalance(income, expenses) {
  const totalExpenses = expenses.reduce((sum, exp) => sum + exp.amount, 0);
  const balance = income - totalExpenses;

  return { totalExpenses, balance };
}
