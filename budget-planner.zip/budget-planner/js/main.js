// js/main.js

import { calculateBalance } from "./budgetService.js";
import { setIncome, addExpense, getExpenses, getIncome } from "./storageService.js";
import { updateUI, renderExpenses } from "./uiService.js";

document.getElementById("addBtn").addEventListener("click", () => {

  let incomeField = document.getElementById("income");

  // FIX ✅ Get value whether it's <input> or <select>
  let incomeInput = incomeField.tagName === "SELECT" 
      ? incomeField.options[incomeField.selectedIndex].value
      : incomeField.value;

  const expenseAmount = document.getElementById("expense").value;
  const desc = document.getElementById("desc").value;

  if (incomeInput !== "") setIncome(incomeInput);
  if (expenseAmount !== "" && desc !== "") addExpense(expenseAmount, desc);

  const income = getIncome();
  const expenses = getExpenses();

  const { totalExpenses, balance } = calculateBalance(income, expenses);

  updateUI(income, totalExpenses, balance);
  renderExpenses(expenses);

  // Clear fields after adding
  document.getElementById("expense").value = "";
  document.getElementById("desc").value = "";
});
